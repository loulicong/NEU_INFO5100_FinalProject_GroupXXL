/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package System;


import System.City.CityList;
import System.PRC.PRCDirectory;
import System.Pregnant.PregnantDirectory;
import System.GODoc.GODocDirectory;
import System.Hospital.HospitalDirectory;
import System.Role.Role;
import System.Role.SystemAdminRole;
import System.UserAccount.UserAccountDirectory;
import System.InRequest.InRequestList;

import java.util.ArrayList;

/**
 *
 * @author MyPC1
 */
public class CareCenterSystem extends Organization{
    
    private static CareCenterSystem business;
    private HospitalDirectory hospitalDirectory;
    private PregnantDirectory pregnantDirectory;
    private GODocDirectory GODocDirectory;
    private InRequestList inRequestList;
    private PRCDirectory prcDirectory;
    private CityList cityList;
    private UserAccountDirectory userAccountDirectory;

    public GODocDirectory getGODocDirectory() {
        return GODocDirectory;
    }

    public void setGODocDirectory(GODocDirectory GODocDirectory) {
        this.GODocDirectory = GODocDirectory;
    }

    public CityList getCityList() {
        return cityList;
    }

    public void setCityList(CityList cityList) {
        this.cityList = cityList;
    }

    public PRCDirectory getPrcDirectory() {
        return prcDirectory;
    }

    public void setPrcDirectory(PRCDirectory prcDirectory) {
        this.prcDirectory = prcDirectory;
    }

    public PregnantDirectory getUserDirectory() {
        return pregnantDirectory;
    }

    public void setUserDirectory(PregnantDirectory pregnantDirectory) {
        this.pregnantDirectory = pregnantDirectory;
    }

    public InRequestList getInRequestList() {
        return inRequestList;
    }

    public void setInRequestList(InRequestList inRequestList) {
        this.inRequestList = inRequestList;
    }

    @Override
    public UserAccountDirectory getUserAccountDirectory() {
        return userAccountDirectory;
    }

    public void setUserAccountDirectory(UserAccountDirectory userAccountDirectory) {
        this.userAccountDirectory = userAccountDirectory;
    }

    public static CareCenterSystem getBusiness() {
        return business;
    }

    public static void setBusiness(CareCenterSystem business) {
        CareCenterSystem.business = business;
    }

    public HospitalDirectory getHospitalDirectory() {
        return hospitalDirectory;
    }


    public void setHospitalDirectory(HospitalDirectory hospitalDirectory) {
        this.hospitalDirectory = hospitalDirectory;
    }


    public CareCenterSystem(HospitalDirectory hospitalDirectory, PregnantDirectory pregnantDirectory, GODocDirectory GODocDirectory, PRCDirectory prcDirectory, CityList cityList) {

        this.hospitalDirectory = hospitalDirectory;
        this.pregnantDirectory = pregnantDirectory;
        this.GODocDirectory = GODocDirectory;
        this.prcDirectory = prcDirectory;
        this.cityList = cityList;
    }

    @Override
    public InRequestList getWorkQueue() {
        return inRequestList;
    }

    @Override
    public void setWorkQueue(InRequestList inRequestList) {
        this.inRequestList = inRequestList;
    }

    public static CareCenterSystem getInstance(){
        if(business==null){
            business=new CareCenterSystem();
        }
        return business;
    }
    
    @Override
    public ArrayList<Role> getSupportedRole() {
        ArrayList<Role> roleList=new ArrayList<Role>();
        roleList.add(new SystemAdminRole());
        return roleList;
    }
    private CareCenterSystem(){
        super(null);
       // networkList=new ArrayList<Network>();
    }

    
    public boolean checkIfUserIsUnique(String userName){
       //
       return false;
    }
}
