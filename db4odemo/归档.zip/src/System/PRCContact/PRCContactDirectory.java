/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package System.PRCContact;

import java.util.ArrayList;

/**
 *
 * @author harold
 */
public class PRCContactDirectory {
    ArrayList<PRCContact> PRCContactList;

    public PRCContactDirectory() {
        PRCContactList = new ArrayList<>();
    }
    public PRCContact createPRC(String name){
        PRCContact PRCcontact = new PRCContact();
        PRCcontact.setName(name);
        PRCContactList.add(PRCcontact);
        return PRCcontact;
    }

    public ArrayList<PRCContact> getPRCtArrayList() {
        return PRCContactList;
    }
}
