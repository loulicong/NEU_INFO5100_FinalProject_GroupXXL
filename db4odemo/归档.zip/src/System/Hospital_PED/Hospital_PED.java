/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package System.Hospital_PED;

import System.PEDoc.PEDoc;

import java.util.ArrayList;

/**
 *
 * @author harold
 */
public class Hospital_PED {
    private ArrayList<PEDoc> PEDocList;

    public Hospital_PED() {
        //this.GODocList
    }

    public ArrayList<PEDoc> getPEDocList() {
        return PEDocList;
    }

    public void setPEDocList(ArrayList<PEDoc> PEDocList) {
        this.PEDocList = PEDocList;
    }
    
    
    
}
