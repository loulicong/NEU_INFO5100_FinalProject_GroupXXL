package System.PreTest;

public class PreTest {
    private String photo;

}
