/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package System.PRC_GO;

import System.GODNurse.GODNurse;

import java.util.ArrayList;

/**
 *
 * @author harold
 */
public class PRC_GO {
    private ArrayList<GODNurse> GODNurseList;

    public PRC_GO() {
        //this.GODocList
    }

    public ArrayList<GODNurse> getGODNurseList() {
        return GODNurseList;
    }

    public void setGODNurseList(ArrayList<GODNurse> GODNurseList) {
        this.GODNurseList = GODNurseList;
    }
    
    
    
}
