/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package System.PRC_PED;

import System.BabyNurse.BabyNurse;

import java.util.ArrayList;

/**
 *
 * @author harold
 */
public class PRC_PED {
    private ArrayList<BabyNurse> BabyNurseList;

    public PRC_PED() {
        //this.GODocList
    }

    public ArrayList<BabyNurse> getBabyNurseList() {
        return BabyNurseList;
    }

    public void setBabyNurseList(ArrayList<BabyNurse> BabyNurseList) {
        this.BabyNurseList = BabyNurseList;
    }
    
    
    
}
