/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package System.Hospital_GO;

import System.GODoc.GODoc;

import java.util.ArrayList;

/**
 *
 * @author harold
 */
public class Hospital_GO {
    private ArrayList<GODoc> GODocList;

    public Hospital_GO() {
        //this.GODocList
    }

    public ArrayList<GODoc> getGODocList() {
        return GODocList;
    }

    public void setGODocList(ArrayList<GODoc> GODocList) {
        this.GODocList = GODocList;
    }
    
    
    
}
